# **ICS 32 Final Project: Chatting with Friends**
1. First run the code as you normally would.

2. Click file to create a new file or open an existing file .

3. At the bottom, type the desired friend you would like to add and add the friend using the "Add User" button.

4. Then the user will pop up on the left side, click the user and type the message you would like to send to the user in the box in the bottom right. 

5. The message will be sent to the user. If you would like to see all messages or new messages type in 'all' and 'new' respectively.

6. Finally to see the message, click the user on the left side again as you need to update the GUI.

# Additional Conciderations
1. __NOTE__ : CLICK COLOR BUTTON TO CHANGE THE UI COLOR

2. __NOTE__ : TO CHANGE USERNAME AND PASSWORD, MUST DO IT IN THE CODE AT LINE 191-193